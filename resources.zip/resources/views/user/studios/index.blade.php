@extends('layouts.app')

@section('title', 'Daftar Studio')

@section('content')
    <div class="mb-6">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h1 class="text-3xl font-semibold text-gray-800">Daftar Studio</h1>
                <p class="text-sm text-gray-500 mt-1">Pilih studio yang tersedia, cek detail, lalu lakukan reservasi.</p>
            </div>

            <form action="{{ route('user.studios.index') }}" method="GET" class="w-full lg:w-auto">
                <div class="flex gap-2">
                    <div class="relative flex-1 lg:w-80">
                        <input
                            type="text"
                            name="search"
                            value="{{ request('search') }}"
                            placeholder="Cari nama / deskripsi studio…"
                            class="w-full pl-4 pr-4 py-2 border rounded-lg text-sm bg-white focus:outline-none focus:ring-2 focus:ring-indigo-200 focus:border-indigo-400"
                        >
                    </div>
                    <button type="submit"
                        class="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700 transition">
                        Cari
                    </button>

                    @if(request()->filled('search'))
                        <a href="{{ route('user.studios.index') }}"
                           class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm hover:bg-gray-200 transition">
                            Reset
                        </a>
                    @endif
                </div>
            </form>
        </div>
    </div>

    @forelse($studios as $studio)
        @break
    @empty
        <div class="bg-white rounded-lg shadow-lg p-8 text-center">
            <div class="mx-auto w-12 h-12 rounded-full bg-indigo-50 flex items-center justify-center mb-3">
                <span class="text-indigo-600 text-xl">🏠</span>
            </div>
            <h2 class="text-lg font-semibold text-gray-800">Belum ada studio yang tampil</h2>
            <p class="text-sm text-gray-500 mt-1">
                Biasanya ini karena status studio belum <b>active</b> atau datanya belum ada.
            </p>
            <p class="text-xs text-gray-400 mt-2">
                Jika kamu yakin ada data: cek kolom <b>status</b> di tabel <b>studios</b> apakah bernilai <b>active</b>.
            </p>
        </div>
    @endforelse

    @if($studios->count() > 0)
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            @foreach($studios as $studio)
                <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
                    {{-- Image / Placeholder --}}
                    @php
                        $hasImage = !empty($studio->image);
                    @endphp

                    @if($hasImage)
                        <img
                            src="{{ asset('storage/' . $studio->image) }}"
                            alt="{{ $studio->name }}"
                            class="w-full h-44 object-cover"
                            onerror="this.style.display='none'; this.parentElement.querySelector('.fallback').classList.remove('hidden');"
                        >
                        <div class="fallback hidden w-full h-44 bg-gradient-to-br from-indigo-50 to-gray-50 flex items-center justify-center">
                            <div class="text-center">
                                <div class="text-2xl font-bold text-indigo-700">{{ strtoupper(substr($studio->name, 0, 1)) }}</div>
                                <div class="text-xs text-gray-500 mt-1">No Image</div>
                            </div>
                        </div>
                    @else
                        <div class="w-full h-44 bg-gradient-to-br from-indigo-50 to-gray-50 flex items-center justify-center">
                            <div class="text-center">
                                <div class="text-2xl font-bold text-indigo-700">{{ strtoupper(substr($studio->name, 0, 1)) }}</div>
                                <div class="text-xs text-gray-500 mt-1">No Image</div>
                            </div>
                        </div>
                    @endif

                    <div class="p-5">
                        <div class="flex items-start justify-between gap-3">
                            <div>
                                <h3 class="text-lg font-semibold text-gray-800 leading-tight">
                                    {{ $studio->name }}
                                </h3>
                                <p class="text-xs text-gray-500 mt-1 line-clamp-2">
                                    {{ $studio->description ?? '—' }}
                                </p>
                            </div>

                            {{-- Badge status (asumsi: active = tersedia) --}}
                            <span class="shrink-0 px-3 py-1 rounded-full text-xs bg-green-100 text-green-700">
                                Tersedia
                            </span>
                        </div>

                        <div class="mt-4 grid grid-cols-2 gap-3 text-sm">
                            <div class="bg-gray-50 rounded-lg p-3">
                                <div class="text-xs text-gray-500">Kapasitas</div>
                                <div class="font-semibold text-gray-800">{{ $studio->capacity }} orang</div>
                            </div>
                            <div class="bg-gray-50 rounded-lg p-3">
                                <div class="text-xs text-gray-500">Harga / jam</div>
                                <div class="font-semibold text-gray-800">
                                    Rp {{ number_format($studio->price_per_hour, 0, ',', '.') }}
                                </div>
                            </div>
                        </div>

                        <div class="mt-4 flex items-center justify-between">
                            <div class="text-xs text-gray-500">
                                {{-- aman: tampilkan jumlah fitur/addon tanpa bergantung nama kolom --}}
                                Fitur: {{ optional($studio->features)->count() ?? 0 }} • Addon: {{ optional($studio->addons)->count() ?? 0 }}
                            </div>

                            <a href="{{ route('user.studios.show', $studio) }}"
                               class="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm hover:bg-indigo-700 transition">
                                Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        {{-- Pagination manual (tanpa links()) --}}
        <div class="mt-6 flex items-center justify-between">
            <a href="{{ $studios->previousPageUrl() }}"
               class="px-4 py-2 rounded-lg text-sm border bg-white hover:bg-gray-50 transition
               {{ $studios->onFirstPage() ? 'opacity-50 pointer-events-none' : '' }}">
                ← Sebelumnya
            </a>

            <div class="text-sm text-gray-600">
                Halaman <span class="font-semibold">{{ $studios->currentPage() }}</span>
                dari <span class="font-semibold">{{ $studios->lastPage() }}</span>
            </div>

            <a href="{{ $studios->nextPageUrl() }}"
               class="px-4 py-2 rounded-lg text-sm border bg-white hover:bg-gray-50 transition
               {{ $studios->hasMorePages() ? '' : 'opacity-50 pointer-events-none' }}">
                Berikutnya →
            </a>
        </div>
    @endif
@endsection
