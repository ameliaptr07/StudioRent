@extends('layouts.app')

@section('title', $studio->name)

@section('content')
    <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
        <h1 class="text-3xl font-semibold text-gray-800">{{ $studio->name }}</h1>
        <p class="text-sm text-gray-600">{{ $studio->description }}</p>
        <p class="mt-4 text-sm text-gray-600">Kapasitas: {{ $studio->capacity }} orang</p>
        <p class="mt-2 text-sm text-gray-600">Harga: Rp {{ number_format($studio->price_per_hour, 0, ',', '.') }}/jam</p>

        <form action="{{ route('my.reservations.store') }}" method="POST" class="mt-6">
            @csrf
            <input type="hidden" name="studio_id" value="{{ $studio->id }}">
            <label for="reservation_date" class="block text-sm font-medium mb-1">Tanggal dan Waktu Reservasi</label>
            <input type="datetime-local" name="reservation_date" required class="w-full border rounded px-4 py-2 text-sm mb-4">

            <button type="submit" class="px-6 py-2 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700 transition duration-300 ease-in-out">
                Reservasi
            </button>
        </form>
    </div>
@endsection
