@extends('layouts.app')

@section('title', 'Dashboard User')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-semibold text-gray-800">Selamat Datang, {{ auth()->user()->name }}!</h1>
    </div>

    <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
        <h2 class="text-xl font-semibold text-gray-800 mb-4">Riwayat Reservasi Anda</h2>

        <table class="min-w-full text-sm text-gray-600">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left">Studio</th>
                    <th class="px-6 py-3 text-left">Tanggal</th>
                    <th class="px-6 py-3 text-left">Status</th>
                    <th class="px-6 py-3 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
            @foreach($reservations as $reservation)
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-6 py-4">{{ $reservation->studio->name }}</td>
                    <td class="px-6 py-4">{{ $reservation->reservation_date }}</td>
                    <td class="px-6 py-4">
                        <span class="px-3 py-1 rounded-full text-xs 
                            @if($reservation->status === 'active') bg-green-200 text-green-700 
                            @elseif($reservation->status === 'canceled') bg-red-200 text-red-700
                            @else bg-gray-200 text-gray-700 
                            @endif">
                            {{ ucfirst($reservation->status) }}
                        </span>
                    </td>
                    <td class="px-6 py-4 text-right">
                        @if($reservation->status === 'active')
                            <form action="{{ route('my.reservations.cancel', $reservation) }}" method="POST" class="inline">
                                @csrf
                                <button type="submit" class="text-red-600 hover:underline text-sm">
                                    Batalkan
                                </button>
                            </form>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>

        <div class="mt-4">
            {{ $reservations->links() }}
        </div>
    </div>

    <a href="{{ route('studios.index') }}" class="px-6 py-3 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition duration-300 ease-in-out">
        Lihat Studio
    </a>
@endsection
