@extends('layouts.app')

@section('title', 'Riwayat Reservasi')

@section('content')
    <h1 class="text-3xl font-semibold text-gray-800 mb-6">Riwayat Reservasi</h1>

    <div class="bg-white rounded-lg shadow-lg p-6">
        <table class="min-w-full text-sm text-gray-600">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left">Studio</th>
                    <th class="px-6 py-3 text-left">Tanggal</th>
                    <th class="px-6 py-3 text-left">Status</th>
                </tr>
            </thead>
            <tbody>
                @foreach($reservations as $reservation)
                    <tr class="border-t hover:bg-gray-50">
                        <td class="px-6 py-4">{{ $reservation->studio->name }}</td>
                        <td class="px-6 py-4">{{ $reservation->reservation_date }}</td>
                        <td class="px-6 py-4">{{ ucfirst($reservation->status) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
