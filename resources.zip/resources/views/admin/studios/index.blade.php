@extends('layouts.app')

@section('title', 'Kelola Studio')

@section('content')
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
            <h1 class="text-3xl font-semibold text-gray-800">Kelola Studio</h1>
            <p class="text-sm text-gray-500 mt-1">Atur data studio dan aktif/nonaktifkan studio agar tampil di sisi user.</p>
        </div>

        <a href="{{ route('admin.studios.create') }}"
           class="px-6 py-3 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition">
            + Tambah Studio
        </a>
    </div>

    @if(session('status'))
        <div class="mb-4 rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-800">
            {{ session('status') }}
        </div>
    @endif

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full text-sm text-gray-600">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left">Nama</th>
                        <th class="px-6 py-3 text-left">Kapasitas</th>
                        <th class="px-6 py-3 text-left">Harga / jam</th>
                        <th class="px-6 py-3 text-left">Status</th>
                        <th class="px-6 py-3 text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                @forelse($studios as $studio)
                    @php
                        $isActive = strtolower($studio->status) === 'active';
                    @endphp

                    <tr class="border-t hover:bg-gray-50">
                        <td class="px-6 py-4 font-medium text-gray-800">
                            {{ $studio->name }}
                        </td>

                        <td class="px-6 py-4">
                            {{ $studio->capacity }}
                        </td>

                        <td class="px-6 py-4">
                            Rp {{ number_format($studio->price_per_hour, 0, ',', '.') }}
                        </td>

                        <td class="px-6 py-4">
                            <span class="px-3 py-1 rounded-full text-xs font-medium
                                {{ $isActive ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700' }}">
                                {{ $isActive ? 'Active' : 'Inactive' }}
                            </span>
                        </td>

                        <td class="px-6 py-4">
                            <div class="flex justify-end items-center gap-3">
                                {{-- Toggle Status --}}
                                <form action="{{ route('admin.studios.toggleStatus', $studio) }}"
                                      method="POST"
                                      class="inline"
                                      onsubmit="return confirm('Ubah status studio ini?');">
                                    @csrf
                                    @method('PATCH')

                                    <button type="submit"
                                        class="px-3 py-2 rounded-lg text-xs font-medium border transition
                                        {{ $isActive
                                            ? 'bg-white text-gray-700 hover:bg-gray-50 border-gray-200'
                                            : 'bg-indigo-600 text-white hover:bg-indigo-700 border-indigo-600'
                                        }}">
                                        {{ $isActive ? 'Nonaktifkan' : 'Aktifkan' }}
                                    </button>
                                </form>

                                {{-- Edit --}}
                                <a href="{{ route('admin.studios.edit', $studio) }}"
                                   class="text-indigo-600 hover:underline text-sm">
                                    Edit
                                </a>

                                {{-- Hapus --}}
                                <form action="{{ route('admin.studios.destroy', $studio) }}"
                                      method="POST"
                                      class="inline"
                                      onsubmit="return confirm('Yakin menghapus studio ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:underline text-sm">
                                        Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="px-6 py-8 text-center text-gray-500">
                            Belum ada studio.
                        </td>
                    </tr>
                @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection
