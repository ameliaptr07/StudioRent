@extends('layouts.app')

@section('title', 'Edit Studio')

@section('content')
    <h1 class="text-2xl font-semibold mb-4">Edit Studio</h1>

    <form action="{{ route('admin.studios.update', $studio) }}" method="POST"
          class="bg-white rounded-lg shadow p-4 space-y-3">
        @csrf
        @method('PUT')

        <div>
            <label class="block text-sm font-medium mb-1">Nama</label>
            <input type="text" name="name" value="{{ old('name', $studio->name) }}"
                   class="w-full border rounded px-2 py-1 text-sm" required>
            @error('name') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Deskripsi</label>
            <textarea name="description" rows="3"
                      class="w-full border rounded px-2 py-1 text-sm">{{ old('description', $studio->description) }}</textarea>
            @error('description') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="grid md:grid-cols-2 gap-3">
            <div>
                <label class="block text-sm font-medium mb-1">Kapasitas (orang)</label>
                <input type="number" name="capacity" value="{{ old('capacity', $studio->capacity) }}"
                       class="w-full border rounded px-2 py-1 text-sm" min="1" required>
                @error('capacity') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
            </div>

            <div>
                <label class="block text-sm font-medium mb-1">Harga per jam</label>
                <input type="number" name="price_per_hour" value="{{ old('price_per_hour', $studio->price_per_hour) }}"
                       class="w-full border rounded px-2 py-1 text-sm" min="0" step="1000" required>
                @error('price_per_hour') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Status</label>
            <select name="status" class="w-full border rounded px-2 py-1 text-sm" required>
                <option value="active" {{ old('status', $studio->status) === 'active' ? 'selected' : '' }}>Active</option>
                <option value="inactive" {{ old('status', $studio->status) === 'inactive' ? 'selected' : '' }}>Inactive</option>
            </select>
            @error('status') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="flex justify-end gap-2">
            <a href="{{ route('admin.studios.index') }}" class="px-3 py-1 text-sm text-gray-700">
                Batal
            </a>
            <button type="submit"
                    class="px-4 py-2 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700">
                Simpan Perubahan
            </button>
        </div>
    </form>
@endsection
