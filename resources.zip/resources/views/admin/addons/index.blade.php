@extends('layouts.app')

@section('title', 'Kelola Addon')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-semibold text-gray-800">Daftar Addon</h1>
        <a href="{{ route('admin.addons.create') }}"
           class="px-6 py-3 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition duration-300 ease-in-out">
            + Tambah Addon
        </a>
    </div>

    <!-- Table Wrapper -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <table class="min-w-full text-sm text-gray-600">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left">Nama</th>
                    <th class="px-6 py-3 text-left">Deskripsi</th>
                    <th class="px-6 py-3 text-left">Harga</th>
                    <th class="px-6 py-3 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($addons as $addon)
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-6 py-4">{{ $addon->name }}</td>
                    <td class="px-6 py-4">{{ $addon->description }}</td>
                    <td class="px-6 py-4">Rp {{ number_format($addon->price, 0, ',', '.') }}</td>
                    <td class="px-6 py-4 text-right space-x-4">
                        <!-- Edit Button -->
                        <a href="{{ route('admin.addons.edit', $addon) }}"
                           class="text-indigo-600 hover:underline text-sm">
                            Edit
                        </a>

                        <!-- Delete Form -->
                        <form action="{{ route('admin.addons.destroy', $addon) }}"
                              method="POST"
                              class="inline"
                              onsubmit="return confirm('Yakin menghapus addon ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 hover:underline text-sm">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="px-6 py-4 text-center text-gray-500">
                        Belum ada addon.
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endsection
