@extends('layouts.app')

@section('title', 'Tambah Addon')

@section('content')
    <h1 class="text-3xl font-semibold mb-6 text-gray-800">Tambah Addon</h1>

    <form action="{{ route('admin.addons.store') }}" method="POST" class="bg-white rounded-lg shadow p-6 space-y-4">
        @csrf

        <div>
            <label class="block text-sm font-medium mb-1">Nama Addon</label>
            <input type="text" name="name" value="{{ old('name') }}"
                   class="w-full border rounded px-4 py-2 text-sm" required>
            @error('name') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Deskripsi</label>
            <textarea name="description" rows="4"
                      class="w-full border rounded px-4 py-2 text-sm">{{ old('description') }}</textarea>
            @error('description') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Harga</label>
            <input type="number" name="price" value="{{ old('price') }}"
                   class="w-full border rounded px-4 py-2 text-sm" min="0" step="1000" required>
            @error('price') <p class="text-xs text-red-600">{{ $message }}</p> @enderror
        </div>

        <div class="flex justify-end gap-2">
            <a href="{{ route('admin.addons.index') }}" class="px-3 py-1 text-sm text-gray-700">
                Batal
            </a>
            <button type="submit"
                    class="px-6 py-2 bg-indigo-600 text-white rounded text-sm hover:bg-indigo-700">
                Simpan
            </button>
        </div>
    </form>
@endsection
