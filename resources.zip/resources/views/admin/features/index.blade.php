@extends('layouts.app')

@section('title', 'Kelola Feature')

@section('content')
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-3xl font-semibold text-gray-800">Daftar Feature</h1>
        <a href="{{ route('admin.features.create') }}"
           class="px-6 py-3 bg-indigo-600 text-white text-sm rounded-lg hover:bg-indigo-700 transition duration-300 ease-in-out">
            + Tambah Feature
        </a>
    </div>

    <!-- Table Wrapper -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <table class="min-w-full text-sm text-gray-600">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left">Nama</th>
                    <th class="px-6 py-3 text-left">Deskripsi</th>
                    <th class="px-6 py-3 text-left">Aksi</th>
                </tr>
            </thead>
            <tbody>
            @forelse($features as $feature)
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-6 py-4">{{ $feature->feature_name }}</td> <!-- Perbaikan di sini -->
                    <td class="px-6 py-4">{{ $feature->description }}</td>
                    <td class="px-6 py-4 text-right space-x-4">
                        <!-- Edit Button -->
                        <a href="{{ route('admin.features.edit', $feature) }}"
                           class="text-indigo-600 hover:underline text-sm">
                            Edit
                        </a>

                        <!-- Delete Form -->
                        <form action="{{ route('admin.features.destroy', $feature) }}" method="POST" class="inline"
                              onsubmit="return confirm('Yakin menghapus feature ini?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-600 hover:underline text-sm">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="3" class="px-6 py-4 text-center text-gray-500">
                        Belum ada feature.
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
@endsection
