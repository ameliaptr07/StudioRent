@extends('layouts.app')

@section('content')
<div class="flex">
    <!-- Sidebar -->
    <div class="w-64 bg-gray-800 text-white min-h-screen p-5">
        <h2 class="text-2xl font-bold mb-6">Admin Dashboard</h2>
        <ul>
            <li>
                <a href="{{ route('admin.studios.index') }}" class="block py-2 px-4 rounded-lg hover:bg-gray-700 transition duration-300 ease-in-out">Studios</a>
            </li>
            <li>
                <a href="{{ route('admin.addons.index') }}" class="block py-2 px-4 rounded-lg hover:bg-gray-700 transition duration-300 ease-in-out">Addons</a>
            </li>
            <li>
                <a href="{{ route('admin.features.index') }}" class="block py-2 px-4 rounded-lg hover:bg-gray-700 transition duration-300 ease-in-out">Features</a>
            </li>
            <li>
                <a href="{{ route('admin.reports.index') }}" class="block py-2 px-4 rounded-lg hover:bg-gray-700 transition duration-300 ease-in-out">Reports</a>
            </li>
            <!-- Profile Link -->
            <li class="mt-6">
                <a href="{{ route('profile.edit') }}" class="block py-2 px-4 rounded-lg hover:bg-gray-700 transition duration-300 ease-in-out">Profile</a>
            </li>
        </ul>

        <!-- Logout Button -->
        <form action="{{ route('logout') }}" method="POST" class="mt-6">
            @csrf
            <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600">
                Logout
            </button>
        </form>
    </div>

    <!-- Main Content -->
    <div class="flex-1 p-8 bg-gray-100">
        <div class="container mx-auto">
            <h1 class="text-3xl font-semibold text-gray-800">Selamat datang, Admin!</h1>
            <p class="mt-4 text-lg text-gray-600">Ini adalah halaman dashboard admin.</p>

            <!-- Dashboard Stats -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
                <div class="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-200 transform hover:scale-105">
                    <h3 class="text-2xl font-semibold text-gray-700">Total Studios</h3>
                    <p class="text-gray-600">150 Studios</p>
                </div>
                <div class="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-200 transform hover:scale-105">
                    <h3 class="text-2xl font-semibold text-gray-700">Active Addons</h3>
                    <p class="text-gray-600">20 Addons</p>
                </div>
                <div class="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transition-shadow duration-200 transform hover:scale-105">
                    <h3 class="text-2xl font-semibold text-gray-700">Pending Reports</h3>
                    <p class="text-gray-600">5 Reports</p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
