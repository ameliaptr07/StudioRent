@extends('layouts.app')

@section('title', 'Laporan Reservasi')

@section('content')
    <div class="flex items-start justify-between gap-4 mb-6">
        <div>
            <h1 class="text-3xl font-semibold text-gray-800">Laporan Reservasi Studio</h1>
            <p class="mt-1 text-sm text-gray-600">
                Ringkasan seluruh reservasi yang masuk. Gunakan ini untuk kontrol jadwal & monitoring aktivitas.
            </p>
        </div>

        <div class="flex items-center gap-2">
            <a href="{{ route('admin.dashboard') }}"
               class="px-4 py-2 text-sm rounded-lg border border-gray-200 bg-white hover:bg-gray-50 transition">
                ← Kembali
            </a>

            <button type="button" onclick="window.print()"
                    class="px-5 py-2.5 text-sm rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition">
                Cetak
            </button>
        </div>
    </div>

    {{-- Summary cards --}}
    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div class="bg-white rounded-xl shadow p-4 border border-gray-100">
            <p class="text-xs text-gray-500">Total Reservasi</p>
            <p class="text-2xl font-semibold text-gray-800">{{ $reservations->count() }}</p>
        </div>
        <div class="bg-white rounded-xl shadow p-4 border border-gray-100">
            <p class="text-xs text-gray-500">Studio Terlibat</p>
            <p class="text-2xl font-semibold text-gray-800">
                {{ $reservations->pluck('studio_id')->unique()->count() }}
            </p>
        </div>
        <div class="bg-white rounded-xl shadow p-4 border border-gray-100">
            <p class="text-xs text-gray-500">User Terlibat</p>
            <p class="text-2xl font-semibold text-gray-800">
                {{ $reservations->pluck('user_id')->unique()->count() }}
            </p>
        </div>
    </div>

    {{-- Table --}}
    <div class="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100">
        <div class="px-6 py-4 border-b bg-gray-50 flex items-center justify-between">
            <p class="text-sm font-semibold text-gray-700">Daftar Reservasi</p>
            <p class="text-xs text-gray-500">
                Terakhir update: {{ now()->format('d M Y, H:i') }}
            </p>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full text-sm text-gray-700">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left font-semibold text-gray-600">Studio</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-600">Pengguna</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-600">Mulai</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-600">Selesai</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-600">Status</th>
                    </tr>
                </thead>

                <tbody class="divide-y">
                    @forelse($reservations as $reservation)
                        @php
                            // aman kalau start_time/end_time tipe string/datetime
                            $start = $reservation->start_time ? \Carbon\Carbon::parse($reservation->start_time) : null;
                            $end   = $reservation->end_time ? \Carbon\Carbon::parse($reservation->end_time) : null;

                            // Status sederhana berdasarkan waktu
                            $status = 'Terjadwal';
                            if ($end && $end->isPast()) $status = 'Selesai';
                            elseif ($start && $start->isPast() && (!$end || $end->isFuture())) $status = 'Berjalan';

                            $badge = match ($status) {
                                'Berjalan' => 'bg-amber-100 text-amber-800',
                                'Selesai' => 'bg-green-100 text-green-800',
                                default => 'bg-indigo-100 text-indigo-800',
                            };
                        @endphp

                        <tr class="hover:bg-gray-50 transition">
                            <td class="px-6 py-4">
                                <div class="font-semibold text-gray-800">
                                    {{ $reservation->studio->name ?? '-' }}
                                </div>
                                <div class="text-xs text-gray-500">
                                    ID Reservasi: #{{ $reservation->id }}
                                </div>
                            </td>

                            <td class="px-6 py-4">
                                <div class="font-semibold text-gray-800">
                                    {{ $reservation->user->name ?? '-' }}
                                </div>
                                <div class="text-xs text-gray-500">
                                    {{ $reservation->user->email ?? '' }}
                                </div>
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($start)
                                    <div class="font-medium text-gray-800">{{ $start->format('d M Y') }}</div>
                                    <div class="text-xs text-gray-500">{{ $start->format('H:i') }}</div>
                                @else
                                    <span class="text-gray-500">-</span>
                                @endif
                            </td>

                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($end)
                                    <div class="font-medium text-gray-800">{{ $end->format('d M Y') }}</div>
                                    <div class="text-xs text-gray-500">{{ $end->format('H:i') }}</div>
                                @else
                                    <span class="text-gray-500">-</span>
                                @endif
                            </td>

                            <td class="px-6 py-4">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold {{ $badge }}">
                                    {{ $status }}
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-6 py-10 text-center">
                                <div class="text-gray-500">
                                    Belum ada reservasi yang tercatat.
                                </div>
                                <div class="text-xs text-gray-400 mt-1">
                                    Nanti kalau user mulai booking, data akan muncul di sini.
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection
