<nav class="bg-white border-b shadow-sm">
    @php
        $user = auth()->user();
        $roleName = $user?->role?->name;

        // Arahkan Dashboard sesuai role
        if ($roleName === 'Admin') {
            $dashboardUrl = route('admin.dashboard');
        } elseif ($roleName === 'Manager') {
            $dashboardUrl = route('manager.dashboard');
        } else {
            // Penyewa / user biasa
            $dashboardUrl = route('dashboard.user');
        }

        // Active state untuk styling menu
        $isDashboardActive =
            request()->routeIs('admin.dashboard') ||
            request()->routeIs('manager.dashboard') ||
            request()->routeIs('dashboard.user') ||
            request()->is('dashboard');

        $isProfileActive = request()->routeIs('profile.edit');
    @endphp

    <div class="container mx-auto px-4">
        <div class="flex items-center justify-between h-14">
            {{-- Left: Brand --}}
            <div class="flex items-center gap-3">
                <a href="{{ url('/') }}" class="text-lg font-semibold text-indigo-600">
                    StudioRent
                </a>

                @auth
                    <span class="text-xs text-gray-500 hidden sm:inline">
                        Hai, <span class="font-medium text-gray-700">{{ $user->name }}</span>
                        @if($roleName)
                            <span class="ml-1 px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 text-[10px]">
                                {{ $roleName }}
                            </span>
                        @endif
                    </span>
                @endauth
            </div>

            {{-- Right: Menu --}}
            <div class="flex items-center gap-3 text-sm">
                @auth
                    {{-- Dashboard (role-based) --}}
                    <a href="{{ $dashboardUrl }}"
                       class="px-3 py-2 rounded-lg transition
                              {{ $isDashboardActive ? 'bg-indigo-50 text-indigo-700' : 'text-gray-700 hover:text-indigo-600 hover:bg-gray-50' }}">
                        Dashboard
                    </a>

                    {{-- Profile --}}
                    <a href="{{ route('profile.edit') }}"
                       class="px-3 py-2 rounded-lg transition
                              {{ $isProfileActive ? 'bg-indigo-50 text-indigo-700' : 'text-gray-700 hover:text-indigo-600 hover:bg-gray-50' }}">
                        Profil
                    </a>

                    {{-- Logout --}}
                    <form action="{{ route('logout') }}" method="POST" class="inline">
                        @csrf
                        <button type="submit"
                                class="px-3 py-2 rounded-lg text-red-600 hover:text-red-700 hover:bg-red-50 transition">
                            Logout
                        </button>
                    </form>
                @else
                    <a href="{{ route('login') }}"
                       class="px-3 py-2 rounded-lg text-gray-700 hover:text-indigo-600 hover:bg-gray-50 transition">
                        Login
                    </a>

                    @if (Route::has('register'))
                        <a href="{{ route('register') }}"
                           class="px-3 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition">
                            Register
                        </a>
                    @endif
                @endauth
            </div>
        </div>
    </div>
</nav>
