<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>@yield('title', 'StudioRent')</title>

    <meta name="csrf-token" content="{{ csrf_token() }}">

    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="bg-gray-100 min-h-screen antialiased">
    <div class="min-h-screen flex flex-col">
        <!-- Navigasi -->
        <header class="bg-white shadow-md py-3">
            <div class="container mx-auto px-4 flex justify-between items-center">
                <!-- Logo atau Judul -->
                <a href="{{ url('/') }}" class="text-lg font-semibold text-gray-800">StudioRent</a>

                <!-- Menu Login atau Dashboard -->
                <div>
                    @if (Auth::check())
                        <!-- Jika sudah login, tampilkan Dashboard -->
                        <a href="{{ route('admin.dashboard') }}" class="text-sm text-gray-600 hover:text-indigo-600">Dashboard</a>
                    @else
                        <!-- Jika belum login, tampilkan Login -->
                        <a href="{{ route('login') }}" class="text-sm text-gray-600 hover:text-indigo-600">Login</a>
                    @endif
                </div>
            </div>
        </header>

        <!-- Konten Utama -->
        <main class="flex-1 container mx-auto px-4 py-6">
            @if (session('status'))
                <div class="mb-4 px-4 py-2 rounded bg-green-100 text-green-800 text-sm">
                    {{ session('status') }}
                </div>
            @endif

            @if (session('error'))
                <div class="mb-4 px-4 py-2 rounded bg-red-100 text-red-800 text-sm">
                    {{ session('error') }}
                </div>
            @endif

            @yield('content')
        </main>

        <!-- Footer -->
        <footer class="border-t bg-white">
            <div class="container mx-auto px-4 py-3 text-xs text-gray-500 flex justify-between">
                <span>&copy; {{ date('Y') }} StudioRent</span>
                <span>UAS Pemrograman Web Lanjut</span>
            </div>
        </footer>
    </div>
</body>
</html>
